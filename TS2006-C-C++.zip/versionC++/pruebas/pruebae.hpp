         "EOF expected",
         "palabra expected",
         "not expected",
