#define EOF_Sym	0	/* EOF */
#define palabraSym	1	/* palabra */
#define No_Sym	2	/* not */
#define MAXT	No_Sym	/* Max Terminals */
